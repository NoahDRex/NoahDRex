## Como contribuir para o Guia de aprendizado na Nuvem

O Guia Learn to cloud ainda está em fase inicial e apenas com conteúdo estático. Temos planos para crescer! Por enquanto, estamos procurando por contribuições do Projeto. Em cada fase há um Projetos Comunitários
seção, sinta-se à vontade para abrir uma issue com sua ideia de projeto.

Obrigado! :heart: :heart: :heart:

GPS and Rishab
