<!-- TODO -->
<!-- ```mermaid
flowchart TD;
A(Como aprender cloud)--B{Está comfortable con fundamentos de Linux?};
B--SI--C{Can you script or code?};
B--No--F[Time to learn some Linux!];
C--SI--D{Have you done the cloud resume challenge?};
C--NO--E[Learn fundamentals of programming]
D--SI--H{Are you comfortable with DevOps practices?};
D--NO--G[Do the Azure/AWS/GCP resume challenge];
H--SI--I[Start applying to roles!];
H--NO--J[Learn VC, CI/CD, and IaC];
``` -->