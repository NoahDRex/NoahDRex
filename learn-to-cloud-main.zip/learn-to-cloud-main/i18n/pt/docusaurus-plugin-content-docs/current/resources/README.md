# Fontes de estudo

| Título | Fonte |
| :----- | :---- |
| [Learning how to learn](https://barbaraoakley.com/books/learning-how-to-learn/) | Um excelente livro que me ajudou a melhorar como eu aprendo. |
| [Deep work](https://www.calnewport.com/books/deep-work/) | Outro ótimo livro, desta vez sobre como focar e conseguir se aprofundar no trabalho no seu dia. |
| [How I study for certs](https://youtu.be/fpPCZqfOBJs) | Um vídeo com algumas dicas que eu peguei pelo caminho. |
| [Pomodoro technique](https://en.wikipedia.org/wiki/Pomodoro_Technique) | Um bom método para quebrar o seu tempo de estudo. |
| [How I study for certifications](https://acloudguru.com/blog/engineering/from-student-to-engineer-how-to-study-smarter-for-cloud-cert) | Algumas dicas para estudar para certificações cloud. |
