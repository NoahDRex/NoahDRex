# Fontes sobre currículo

Autor: [Gwyneth Pena-Siguenza](https://twitter.com/madebygps)


| Título | Fonte |
| :----- | :---- |
| [My cloud engineer resume](https://youtu.be/HiKQHDUUmTI) | Eu te conduzo pelo meu currículo na nuvem e pelas boas práticas que tenho. |
| [My FAANGM resume \| Resume that got me into Google](https://youtu.be/LEbqEwhsRWE) | Uma visão geral do currículo de @rishabkumar7 |
| [20+ tech resume checklist](https://twitter.com/TiffanyJachja/status/1528081140422266887) | Uma incrível thread no Twitter criada por [Tiffany Jachja](https://twitter.com/TiffanyJachja) com muitas melhores práticas sobre montar seu currículo. |
| [Tech resume and cover letter tips](https://youtu.be/yTfrEpeBjAs) | Mais dicas feitas por mim. |
