<!-- docs/pt/_sidebar.md -->

- Comece aqui
  - [Bem Vindo](/#bem-vindo)

- Guia

  - [Fase 0: Começando do zero](/pt/phase0/README.md)
  - [Fase 1: Fundamentos de Linux, Redes, and Scripts](/pt/phase1/README.md)
  - [Fase 2: Fundamentos de programação](/pt/phase2/README.md)
  - [Fase 3: Fundamentos de Cloud Platform](/pt/phase3/README.md)
  - [Fase 4: Fundamentos de DevOps](/pt/phase4/README.md)
  - [Fase 5: Fundamentos de segurança na nuvem](/pt/phase5/README.md)

- Fontes

  - [Mais projetos](/pt/projects/README.md)
  - [Dicas de estudos](/pt/resources/readme.md)
  - [Fontes sobre currículo](/pt/resources/resume-tips.md)

- Siga o guia

  - [Twitter](https://twitter.com/learntocloud)
  - [Instagram](https://instagram.com/learntocloudguide)
