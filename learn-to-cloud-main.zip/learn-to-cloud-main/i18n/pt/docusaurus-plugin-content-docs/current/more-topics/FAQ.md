# FAQ

## Qual nuvem aprender?

Todos os dias você encontrará pessoas discutindo sobre qual é o melhor online.

Confira as listas de empregos em sua região e escolha aquela com mais resultados. ESCOLHA UM E FIQUE COM ELE. Os fundamentos são os mesmos e nosso conselho é o mesmo.

Seja qual for a nuvem que você escolher, certifique-se de criar uma conta e configurar alguns orçamentos e alertas para não acordar com surpresas em sua fatura. [Aqui](https://youtu.be/FZD0s7KE83Y) está como fazer isso no portal do Azure e na [AWS](https://www.youtube.com/watch?v=fvz0cphjHjg).


## As plataformas pagas de aprendizado de nuvem valem a pena?

Existem plataformas como [A Cloud Guru](https://acloudguru.com) e [CloudAcademy](https://cloudacademy.com) que você pode pagar por uma assinatura mensal ou anual e ter acesso a conteúdo e ambientes de laboratório para o seu aprendizado.

Isso ajuda você a evitar gastar seu próprio dinheiro em suas próprias contas da AWS e do Azure, o que, quando você está começando, é uma coisa boa. No final das contas, cabe a você.

Eu (GPS) tinha uma assinatura da Cloud Guru e da Linux Academy quando estava começando, mas a empresa que eu trabalhava pagava por isso, talvez esse seja um benefício pelo qual sua empresa também possa pagar.
