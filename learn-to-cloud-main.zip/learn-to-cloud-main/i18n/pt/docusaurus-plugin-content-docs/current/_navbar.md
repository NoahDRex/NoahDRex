<!-- pt/_navbar.md -->

* [Podcast](https://www.youtube.com/channel/UCbEDpkjQYiDn9XfssWGuyHQ/)

* Redes Sociais

  * [Twitter](https://twitter.com/learntocloud)
  * [Discord](https://discord.gg/dr2kvtA726)
  * [Instagram](https://www.instagram.com/learntocloudguide/)

* [Colaboradores](../Contributors.md)

* Traduções

  * [En](/)
  * [Pt](../pt/README.md)
  * [Fr](../fr/README.md)
  * [Es](../es/)
