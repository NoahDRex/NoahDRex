<!-- _coverpage.md -->

![logo](../img/Logo-03.svg)

[![GitHub license](https://img.shields.io/github/license/learntocloud/learn-to-cloud.svg)](https://github.com/learntocloud/learn-to-cloud/blob/master/LICENSE)
[![PRs são bem vindos](https://img.shields.io/badge/PRs-welcome-brightgreen.svg?style=flat-square)](http://makeapullrequest.com)


[![GitHub forks](https://img.shields.io/github/forks/learntocloud/learn-to-cloud.svg?style=social&label=Fork&maxAge=2592000)](https://GitHub.com/learntocloud/learn-to-cloud/network/)
[![GitHub stars](https://img.shields.io/github/stars/learntocloud/learn-to-cloud.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/learntocloud/learn-to-cloud/stargazers/)


> Um guia de 6 meses para os fundamentos da computação em nuvem

- Gratuito e de código aberto
- Fontes, tarefas, e projetos
- Construído a partir da experiência em primeira mão

[GitHub](https://github.com/learntocloud/learn-to-cloud/)
[Primeiros passos](#bem-vindo)