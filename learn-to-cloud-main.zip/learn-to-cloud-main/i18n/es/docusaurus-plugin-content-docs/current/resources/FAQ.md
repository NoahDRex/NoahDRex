# FAQ

## ¿Qué Nube aprender?

Todos los días te vas a encontrar con personas argumentando acerca de cual es la mejor.

Revisa las listas de trabajo en tu área y elegi la que tiene mayor cantidad de resultados. ELEGUI UNA Y QUEDATE CON ESA. Los fundamentos son los mismos y nuestros consejos también.

Cualquier que sea la nube que elijas, asegurate de crear una cuenta y configurar una alerta de presupuesto así no te vas a desayunar con sorpresas en tus facturas. [Acá](https://youtu.be/FZD0s7KE83Y) está como configfurarlo en el portal de Azure y acá para [AWS](https://www.youtube.com/watch?v=fvz0cphjHjg).

## ¿Valen la pena plataformas pagas para aprender sobre Nube?

Existen plataformas por ahí como [A Cloud Guru](https://acloudguru.com) y [CloudAcademy](https://cloudacademy.com)
que podes pagar una suscripción mensual o anual y obtener acceso a contendio y laboratorios para tu propio aprendizaje.

Estas te ayudan a evitar gastar tu propio dinero en tus propias cuentas de AWS y Azure, lo que es bueno cuando uno está comenzando. En última instancia, si te registras en una, depende de ti.

I (GPS) tuve una suscripción a A Cloud Guru y Linux Academy cuando estaba comenzado, mi trabajo lo pagaba, puede ser un beneficio que tu trabajo también puede pagar.
