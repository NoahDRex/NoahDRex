# Recursos para crear tu currículum

Autora: [Gwyneth Pena-Siguenza](https://twitter.com/madebygps)

| Título                                                                                    | Recursos                                                                                                             |
| :---------------------------------------------------------------------------------------- | :------------------------------------------------------------------------------------------------------------------- |
| [Mi currículum de Ingeniero en Nuve](https://youtu.be/HiKQHDUUmTI)                        | Te guío a través de mi currículum y las mejores prácticas que tengo                                                  |
| [MI currículum FAANGM que me llevó a Google](https://youtu.be/LEbqEwhsRWE)                | Descripción general del currículum de Rishab                                                                         |
| [20+ tech resume checklist](https://twitter.com/TiffanyJachja/status/1528081140422266887) | An amazing Twitter thread by [Tiffany Jachja](https://twitter.com/TiffanyJachja) with lots of resume best practices. |
| [Currículum técnico y carta de presentación](https://youtu.be/yTfrEpeBjAs)                | Mäs consejos míos                                                                                                    |
