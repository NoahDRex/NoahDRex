# Ресурси для резюме

Автор: [Gwyneth Pena-Siguenza](https://twitter.com/madebygps)


 Назва   | Ресурс    |
 :---------- | :----------- |
 [my cloud engineer resume](https://youtu.be/HiKQHDUUmTI)   | Я ознайомлю вас з моїм резюме та найкращими практиками, які я маю |
[My FAANGM resume Resume that got me into Google](https://youtu.be/LEbqEwhsRWE) | Rishab's - огляд резюме|
 [20+ tech resume checklist](https://twitter.com/TiffanyJachja/status/1528081140422266887) | Дивовижний допис у Твіттері від [Tiffany Jachja](https://twitter.com/TiffanyJachja) з великою кількістю найкращих практик резюме.  |
[Tech resume and cover letter tips](https://youtu.be/yTfrEpeBjAs) | Більше порад від мене |