# Ресурси для навчання

 | Назва                   | Ресурс                                                                                                                                             |
 | :------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------ |
 | [Learning how to learn](https://barbaraoakley.com/books/learning-how-to-learn/)| Чудова книга, яка допомогла мені покращити моє навчання.
 | [Deep work](https://www.calnewport.com/books/deep-work/)             | Ще одна чудова книга, цього разу про те, як зосередитися і виділити час на роботу. |
 | [How I study for certs](https://youtu.be/fpPCZqfOBJs)               | Відео з деякими порадами, які я вивчаю по ходу.                                                               |
 [Pomodoro technique](https://en.wikipedia.org/wiki/Pomodoro_Technique) |Чудовий спосіб розбити свій час навчання.
| [How I study for certifications](https://acloudguru.com/blog/engineering/from-student-to-engineer-how-to-study-smarter-for-cloud-cert) | Кілька порад щодо підготовки до хмарних сертифікацій.


 