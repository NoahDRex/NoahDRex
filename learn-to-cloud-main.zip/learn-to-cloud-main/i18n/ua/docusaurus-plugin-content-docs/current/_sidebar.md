<!-- docs/_sidebar.md -->

- Починаєм
  - [Вітаємо](/#Вітаємо)

- Посібник

  - [Етап 0: Починаємо з нуля](phase0/README.md)
  - [Етап 1: Основи Лінукс та мереж](ua/phase1/README.md)
  - [Етап 2: Основи програмування](ua/phase2/README.md)
  - [Етап 3: Основи Хмарних платформ](ua/phase3/README.md)
  - [Етап 4: Основи DevOps](ua/phase4/README.md)

- Ресурси

  - [Більше проектів](projects/README.md)
  - [Поради та ресурси для навчання](resources/readme.md)
  - [Ресурси для резюме](resources/resume-tips.md)

- Слідкувати за посібником

  - [Twitter](https://twitter.com/learntocloud)
  - [Instagram](https://instagram.com/learntocloudguide)
