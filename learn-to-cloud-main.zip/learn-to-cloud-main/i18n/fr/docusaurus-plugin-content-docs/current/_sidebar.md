<!-- docs/_sidebar.md -->

- Commencez Ici
  - [Bienvenue](/#Bienvenue)

- Guide

  - [Phase 0: Starting from zero](phase0/README.md)
  - [Phase 1: Linux,Réseau,et les Fondamentaux du scripting](fr/phase1/README.md)
  - [Phase 2: Les fondamentaux de la programmation](fr/phase2/README.md)
  - [Phase 3: Fondamentaux des plateformes cloud](fr/phase3/README.md)
  - [Phase 4: Les fondamentaux du DevOps](fr/phase4/README.md)

- Resources

  - [More projects](projects/README.md)
  - [Study tips and resources](resources/readme.md)
  - [Resume Resources](resources/resume-tips.md)

- Follow the guide

  - [Twitter](https://twitter.com/learntocloud)
  - [Instagram](https://instagram.com/learntocloudguide)
