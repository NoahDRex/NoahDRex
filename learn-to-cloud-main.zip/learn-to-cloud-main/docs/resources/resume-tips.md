# Resume Resources

Author: [Gwyneth Pena-Siguenza](https://twitter.com/madebygps)


 Title    | Resource     |
 :---------- | :----------- |
 [my cloud engineer resume](https://youtu.be/HiKQHDUUmTI)   | I walk you through the my resume and best practices I have |
[My FAANGM resume Resume that got me into Google](https://youtu.be/LEbqEwhsRWE) | Rishab's resume overview |
 [20+ tech resume checklist](https://twitter.com/TiffanyJachja/status/1528081140422266887) | An amazing Twitter thread by [Tiffany Jachja](https://twitter.com/TiffanyJachja) with lots of resume best practices.  |
[Tech resume and cover letter tips](https://youtu.be/yTfrEpeBjAs) | More tips by me |