# Study resources

 | Title                     | Resource                                                                                                                                               |
 | :------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------ |
 | [Learning how to learn](https://barbaraoakley.com/books/learning-how-to-learn/)| Great book that helped me improve how I learn                                              |
 | [Deep work](https://www.calnewport.com/books/deep-work/)             | Another great book, this time about how to focus and get deep work time into your day. |
 | [How I study for certs](https://youtu.be/fpPCZqfOBJs)               | A video with some tips I've picked up on the way                                                                  |
 [Pomodoro technique](https://en.wikipedia.org/wiki/Pomodoro_Technique) | A great method to break up your study time.
| [How I study for certifications](https://www.pluralsight.com/resources/blog/cloud/from-student-to-engineer-how-to-study-smarter-for-cloud-certs) | Some tips on studying for Cloud Certifications


 
