## How to contribute to Learn to Cloud Guide

Hello lovely contributors,

The guide content wise is finished and we are no longer looking for contributions there. Where we could always use help is in projects and translations.

Please feel free to add a project in [this page](https://github.com/learntocloud/learn-to-cloud/blob/main/projects/README.md).

If you'd like to help translate the guide, please open [an issue](https://github.com/learntocloud/learn-to-cloud/issues) and have a look at our [Language Support Page](https://github.com/learntocloud/learn-to-cloud/wiki/Language-Support-for-LTC)

Thanks! :heart: :heart: :heart:

GPS and Rishab
